from django.contrib import admin
from .models import Train,Book,Datasave,Cancellation

# Register your models here.
admin.site.register(Train)
admin.site.register(Book)
admin.site.register(Datasave)
admin.site.register( Cancellation)
