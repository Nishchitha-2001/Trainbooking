from django.db import models
from django.contrib.auth.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
# Create your models here.
class Train(models.Model):
    list_id = models.AutoField(max_length=4, primary_key=True)
    train_name = models.CharField(max_length=50)
    from1 = models.CharField(max_length=50)
    to = models.CharField(max_length=50)
    date = models.DateField()
    time = models.TimeField()

    def __str__(self):
        return self.train_name

class Book(models.Model):
    book_no=models.AutoField(max_length=3,primary_key=True)
    email_id=models.EmailField()
    # no_seats=models.IntegerField(max_length=2)
    no_seats = models.PositiveIntegerField(
        validators=[
            MinValueValidator(1),
            MaxValueValidator(33),
        ])
    def __str__(self):
        return self.email_id
#
class Datasave(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    display_no = models.AutoField(max_length=3, primary_key=True)
    email_id= models.EmailField()
    no_seats= models.PositiveIntegerField(validators=[
            MinValueValidator(1),
            MaxValueValidator(33),])
    train_name= models.CharField(max_length=50)
    from1 = models.CharField(max_length=50)
    to = models.CharField(max_length=50)
    date = models.DateField()
    time = models.TimeField()
    seat_number = models.PositiveIntegerField()

    def __str__(self):
        return self.email_id


class Cancellation(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    booking = models.ForeignKey(Datasave, on_delete=models.CASCADE)
    seats_to_cancel = models.PositiveIntegerField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'Cancellation for Booking {self.booking.display_no} by {self.user.username}'