from django.shortcuts import render
from django.shortcuts import render,redirect,get_object_or_404
from django.urls import reverse
from django.db import transaction
from django.contrib.auth.models import User
from .models import Train,Book,Datasave
from django.contrib.auth import login,authenticate,logout
from django.shortcuts import render, redirect
from .forms import ListForm, BookForm,CancellationForm
from django.core.mail import send_mail
from django.conf import settings
from datetime import datetime, timedelta
from django.utils import timezone
from django.contrib import messages
# Create your views
def register(request):
    if request.method=='POST':
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        user=User.objects.create_user(username=username,email=email,password=password)
        user.save()

        return redirect('home')

    return render(request,'register.html')

def login_user(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['pwd']
        user=authenticate(username=username,password=password)
        if user is not None:
            login(request,user)
            return redirect('http://127.0.0.1:8000/list_view/')

        else:
            return render(request,'login.html')

    return render(request,'login.html')

def logout_user(request):
    logout(request)
    return render(request, 'home.html')

def home(request):
    return render(request, 'home.html')


def list_view(request):  # display the data which stored in database
    # add the dictionary during initialization
    # field names as keys
    context = {}  # to put the that we read
    context["dataset"] = Train.objects.all()  # it read all the objects in list class it will store in the  key called dataset
    # the storing of key value pair may be in the form of list or array
    return render(request, "list.html", context)

def book_train(request,pk):
    list1 = Train.objects.get(pk=pk)

    if request.method == "POST":
        form = ListForm(instance=list1, data=request.POST)
        extra_form = BookForm(data=request.POST)

        if form.is_valid() and extra_form.is_valid():
            user = request.user
            email = extra_form.cleaned_data['email_id']
            no_seats = extra_form.cleaned_data['no_seats']
            train_name = list1.train_name
            train_datetime = timezone.make_aware(datetime.combine(list1.date, list1.time))
            current_datetime = timezone.now()

            # Check if the date is before or equal to the current date
            if list1.date > current_datetime.date() or (
                    list1.date == current_datetime.date() and train_datetime <= current_datetime + timedelta(hours=1)):
                last_seat = Datasave.objects.filter(train_name=train_name).order_by('-seat_number').first()
                next_seat_number = last_seat.seat_number + 1 if last_seat else 1

                if next_seat_number + no_seats - 1 <= 33:
                    seat_numbers = list(range(next_seat_number, next_seat_number + no_seats))

                    with transaction.atomic():
                        booking_instance = Datasave(
                            user=user,
                            email_id=email,
                            no_seats=no_seats,
                            train_name=train_name,
                            from1=list1.from1,
                            to=list1.to,
                            date=list1.date,
                            time=list1.time,
                            seat_number=next_seat_number  # Save only the starting seat number
                        )
                        booking_instance.save()

                    subject = 'Booking Confirmation'
                    message = f'Your booking for {train_name} is successful. Your seat numbers are {", ".join(map(str, seat_numbers))}.'
                    from_email = settings.EMAIL_HOST_USER
                    recipient_list = [email]

                    send_mail(subject, message, from_email, recipient_list)
                    messages.info(request,
                                  f'Your booking is successful. Your seat numbers are {next_seat_number} to {next_seat_number + no_seats - 1} Your seat numbers are {", ".join(map(str, seat_numbers))}.')
                else:
                    messages.error(request,
                                   'Seats are not available. Maximum 33 seats can be booked for the selected train.')
            else:
                messages.error(request,
                               'Train cannot be booked. Date should be before or equal to the current date, and the time should be an hour before the train timings.')

            return redirect("display_status")
    else:
        form = ListForm(instance=list1)
        extra_form = BookForm()

    return render(request, "book.html", context={"form": form, "object": list1, 'extra_form': extra_form})

def extra_form(request):
    extra_form = BookForm()
    # Instantiate an empty form

    return render(request, 'extra_form.html', context={'extra_form': extra_form})

def display_status(request):
    context = {}
    context["dataset1"] = Datasave.objects.filter(user=request.user)
    # context["messages"] = messages.get_messages(request)
    if context["dataset1"]:
        messages.success(request, "Your booking status is displayed.")
    else:
        messages.error(request, "No booking records found.")
    return render(request, "status.html", context)

def delete_booking(request, booking_id):
    booking = get_object_or_404(Datasave, display_no=booking_id)
    # Retrieve the booking with the provided booking_id or show a 404 error page

    # Check if the logged-in user owns the booking
    if booking.user == request.user:
        train_datetime = datetime.combine(booking.date, booking.time)
        train_datetime = timezone.make_aware(train_datetime)  # Make it timezone-aware
        current_datetime = timezone.now()

        # Check if the cancellation date is less than the train date
        if booking.date > current_datetime.date() or (
                booking.date == current_datetime.date() and current_datetime >= train_datetime - timedelta(minutes=30)):
            if request.method == 'POST':
                form = CancellationForm(request.POST)

                if form.is_valid():
                    seats_to_cancel = form.cleaned_data['seats_to_cancel']

                    if seats_to_cancel == booking.no_seats:
                        # If all seats are canceled, delete the entire booking
                        booking.delete()
                        messages.success(request, 'Booking canceled.')

                        # Send email to the user
                        subject = 'Booking Cancellation Confirmation'
                        message = f'Your booking for {booking.train_name} on {booking.date} has been canceled. ' \
                                  f'All seats have been canceled.'
                        from_email = settings.EMAIL_HOST_USER  # Use your email address here
                        recipient_list = [booking.email_id]

                        send_mail(subject, message, from_email, recipient_list)

                        return redirect('display_status')
                    elif seats_to_cancel < booking.no_seats:
                        # If some seats are canceled
                        canceled_seats_numbers = []

                        with transaction.atomic():
                            # Update seat numbers for the canceled seats
                            canceled_seats = Datasave.objects.filter(
                                display_no=booking_id,
                                seat_number__gte=booking.seat_number,
                                seat_number__lt=booking.seat_number + seats_to_cancel
                            )

                            for seat in canceled_seats:
                                canceled_seats_numbers.append(seat.seat_number)
                                seat.delete()

                            # Shift seat numbers for the remaining seats
                            remaining_seats = Datasave.objects.filter(
                                display_no=booking_id,
                                seat_number__gte=booking.seat_number + seats_to_cancel
                            )

                            for seat in remaining_seats:
                                seat.seat_number -= seats_to_cancel
                                seat.save()

                            # Update the 'no_seats' field
                            booking.no_seats -= seats_to_cancel
                            booking.save()

                            messages.success(request,
                                             f'Successfully canceled {seats_to_cancel} seats. Your amount will be refunded within 3 to 4 days. '
                                             f'Updated seat numbers: {booking.seat_number} to {booking.seat_number + booking.no_seats - 1}')

                            # Send email to the user
                            subject = 'Booking Cancellation Confirmation'
                            canceled_seats_message = f'Canceled seat numbers: {", ".join(map(str, canceled_seats_numbers))}'  # Construct message
                            message = f'Your booking for {booking.train_name} on {booking.date} has been canceled. ' \
                                      f'{seats_to_cancel} seats have been canceled. ' \
                                      f'{canceled_seats_message}'  # Include canceled seat numbers in the message
                            from_email = settings.EMAIL_HOST_USER  # Use your email address here
                            recipient_list = [booking.email_id]

                            send_mail(subject, message, from_email, recipient_list)

                            return redirect('display_status')
                    else:
                        messages.error(request,
                                       'Invalid number of seats to cancel. You cannot cancel more seats than you booked.')
                else:
                    messages.error(request, 'Invalid form submission.')
            else:
                form = CancellationForm()

            return render(request, 'cancel.html', {'form': form, 'booking': booking})
        else:
            messages.error(request,
                           'Train cannot be canceled. The time should be at least half an hour before the train timings '
                           'if the cancellation date is today.')
            return redirect('display_status')
    else:
        messages.error(request, 'You do not have permission to cancel this booking.')
        return redirect('display_status')