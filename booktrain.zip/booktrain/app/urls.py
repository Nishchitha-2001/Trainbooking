from django.urls import path,re_path
from .import views



urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.login_user, name='login'),
    path('logout/', views.logout_user, name='logout'),
    path('list_view/', views.list_view, name='list_view'),
    path('<int:pk>/book/', views.book_train,name='book_train'),
    path('extra/',views.extra_form,name='extra_form'),
    path('display/',views.display_status,name='display_status'),
    path('delete/<int:booking_id>/', views.delete_booking, name='delete_booking'),
    ]