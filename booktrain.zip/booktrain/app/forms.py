from .models import Train,Book,Datasave
from django import forms
from django.forms import DateInput
from django.core.validators import MinValueValidator, MaxValueValidator


class ListForm(forms.ModelForm):
    class Meta:
        model=Train
        fields="__all__"

class BookForm(forms.ModelForm):
    class Meta:
        model=Book
        fields="__all__"

class DatasavingForm(forms.ModelForm):
    class Meta:
        model =Datasave
        fields = "__all__"

class CancellationForm(forms.Form):
    seats_to_cancel = forms.IntegerField(
        label='Number of Seats to Cancel',
        validators=[
            MinValueValidator(1),
            MaxValueValidator(33),  # Adjust the maximum based on your requirements
        ]
    )